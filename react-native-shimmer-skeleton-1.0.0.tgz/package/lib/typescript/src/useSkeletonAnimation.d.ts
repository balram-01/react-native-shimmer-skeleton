import type { UseSkeletonAnimationOptions, UseSkeletonAnimationReturn } from './types';
/**
 * Core animation hook that powers Skeleton components.
 *
 * Handles:
 * - Shimmer (translateX sweep)
 * - Pulse (opacity breathe)
 * - Wave (same as pulse, consumed by SkeletonGroup for staggering)
 * - Reduced-motion accessibility
 * - Cleanup on unmount
 *
 * @example
 * const { animatedValue, shimmerStyle, pulseStyle } = useSkeletonAnimation({ speed: 1000 });
 */
export declare function useSkeletonAnimation({ speed, delay, animation, direction, }?: UseSkeletonAnimationOptions): UseSkeletonAnimationReturn;
//# sourceMappingURL=useSkeletonAnimation.d.ts.map