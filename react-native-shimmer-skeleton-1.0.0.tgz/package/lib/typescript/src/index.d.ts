export { Skeleton } from './Skeleton';
export { SkeletonGroup } from './SkeletonGroup';
export { useSkeletonAnimation } from './useSkeletonAnimation';
export { themes, SkeletonThemeContext, SkeletonThemeProvider, useSkeletonTheme, } from './themes';
export type { SkeletonThemeProviderProps, ThemeName } from './themes';
export { CardSkeleton, ListItemSkeleton, ProfileSkeleton, ArticleSkeleton, } from './presets';
export type { CardSkeletonProps, ListItemSkeletonProps, ProfileSkeletonProps, ArticleSkeletonProps, } from './presets';
export type { SkeletonProps, SkeletonGroupProps, SkeletonTheme, SkeletonVariant, AnimationType, ShimmerDirection, UseSkeletonAnimationOptions, UseSkeletonAnimationReturn, } from './types';
export { getVariantStyles } from './utils/getVariantStyles';
//# sourceMappingURL=index.d.ts.map