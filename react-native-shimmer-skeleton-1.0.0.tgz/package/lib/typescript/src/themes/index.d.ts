import React from 'react';
import type { SkeletonTheme } from '../types';
export declare const themes: {
    readonly light: SkeletonTheme;
    readonly dark: SkeletonTheme;
    readonly blue: SkeletonTheme;
    readonly purple: SkeletonTheme;
    readonly warm: SkeletonTheme;
};
export type ThemeName = keyof typeof themes;
export declare const SkeletonThemeContext: React.Context<SkeletonTheme>;
export interface SkeletonThemeProviderProps {
    /** Pass a ThemeName string or a custom SkeletonTheme object. */
    theme?: ThemeName | SkeletonTheme;
    children: React.ReactNode;
}
/**
 * Wrap your app (or a section of it) in SkeletonThemeProvider to apply a
 * consistent color scheme to all Skeleton components underneath.
 *
 * @example
 * <SkeletonThemeProvider theme="dark">
 *   <MyScreen />
 * </SkeletonThemeProvider>
 *
 * @example
 * <SkeletonThemeProvider theme={{ baseColor: '#1a1a2e', highlightColor: '#16213e' }}>
 *   <MyScreen />
 * </SkeletonThemeProvider>
 */
export declare function SkeletonThemeProvider({ theme, children, }: SkeletonThemeProviderProps): React.ReactElement;
/**
 * Returns the current skeleton theme from context.
 */
export declare function useSkeletonTheme(): SkeletonTheme;
//# sourceMappingURL=index.d.ts.map