import React from 'react';
import type { SkeletonGroupProps } from './types';
/**
 * `<SkeletonGroup>` manages a group of skeleton children with:
 * - Staggered delay: each `<Skeleton>` child receives an incrementing `delay`
 *   prop so skeletons animate in a wave/ripple pattern.
 * - Content fade-in: when `loading` switches to `false`, the real content
 *   fades in smoothly instead of popping into view.
 *
 * @example
 * <SkeletonGroup loading={isLoading} stagger={80}>
 *   <CardSkeleton />
 *   <CardSkeleton />
 * </SkeletonGroup>
 */
declare const SkeletonGroup: React.MemoExoticComponent<({ loading, stagger, children, style, }: SkeletonGroupProps) => import("react/jsx-runtime").JSX.Element>;
export default SkeletonGroup;
export { SkeletonGroup };
//# sourceMappingURL=SkeletonGroup.d.ts.map