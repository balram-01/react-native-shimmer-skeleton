import React from 'react';
import type { SkeletonProps } from './types';
/**
 * The core `<Skeleton>` component.
 *
 * Renders an animated placeholder that mimics the shape of real content.
 * Supports shimmer, pulse, and wave animation modes out of the box.
 *
 * @example
 * // Simple rectangle
 * <Skeleton width={200} height={20} />
 *
 * @example
 * // Circle avatar
 * <Skeleton variant="circle" width={48} height={48} />
 *
 * @example
 * // Text line
 * <Skeleton variant="text" width="80%" />
 */
declare const Skeleton: React.MemoExoticComponent<({ width, height, borderRadius, variant, animation, speed, delay, direction, baseColor, highlightColor, style, children, testID, }: SkeletonProps) => import("react/jsx-runtime").JSX.Element>;
export default Skeleton;
export { Skeleton };
//# sourceMappingURL=Skeleton.d.ts.map