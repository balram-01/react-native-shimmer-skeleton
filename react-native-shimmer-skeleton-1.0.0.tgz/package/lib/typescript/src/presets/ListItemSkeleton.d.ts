import React from 'react';
import type { SkeletonProps } from '../types';
export interface ListItemSkeletonProps extends Pick<SkeletonProps, 'animation' | 'speed' | 'baseColor' | 'highlightColor' | 'delay'> {
    /** Size of the avatar circle. Defaults to 48. */
    avatarSize?: number;
    /** Show the right-side action/timestamp line. Defaults to true. */
    showAction?: boolean;
}
/**
 * Pre-built list-item skeleton:
 *
 *  [●]  ████████████████   ████
 *       ███████████████████████
 *
 * Avatar circle + two text lines + optional timestamp/action.
 */
declare const ListItemSkeleton: React.MemoExoticComponent<({ animation, speed, baseColor, highlightColor, delay, avatarSize, showAction, }: ListItemSkeletonProps) => import("react/jsx-runtime").JSX.Element>;
export default ListItemSkeleton;
export { ListItemSkeleton };
//# sourceMappingURL=ListItemSkeleton.d.ts.map