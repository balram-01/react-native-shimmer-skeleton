import React from 'react';
import type { SkeletonProps } from '../types';
export interface ProfileSkeletonProps extends Pick<SkeletonProps, 'animation' | 'speed' | 'baseColor' | 'highlightColor' | 'delay'> {
    /** Avatar circle diameter. Defaults to 88. */
    avatarSize?: number;
    /** Show the two action buttons at the bottom. Defaults to true. */
    showButtons?: boolean;
    /** Number of bio lines. Defaults to 2. */
    bioLines?: number;
}
/**
 * Pre-built profile skeleton:
 *
 *        [●●●●●]         ← large avatar circle (centred)
 *    ████████████        ← display name (centred)
 *    ██████████          ← bio line 1
 *    ████████████████    ← bio line 2
 *   [  Follow  ] [  DM  ]
 */
declare const ProfileSkeleton: React.MemoExoticComponent<({ animation, speed, baseColor, highlightColor, delay, avatarSize, showButtons, bioLines, }: ProfileSkeletonProps) => import("react/jsx-runtime").JSX.Element>;
export default ProfileSkeleton;
export { ProfileSkeleton };
//# sourceMappingURL=ProfileSkeleton.d.ts.map