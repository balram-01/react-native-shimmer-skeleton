import React from 'react';
import type { SkeletonProps } from '../types';
export interface ArticleSkeletonProps extends Pick<SkeletonProps, 'animation' | 'speed' | 'baseColor' | 'highlightColor' | 'delay'> {
    /** Show the hero banner image. Defaults to true. */
    showHero?: boolean;
    /** Number of body paragraph lines. Defaults to 6. */
    paragraphLines?: number;
    /** Show author row (avatar + name + date). Defaults to true. */
    showAuthor?: boolean;
}
/**
 * Full-page article / blog post skeleton:
 *
 * ╔═══════════════════════════════╗
 * ║      [hero image 200px]       ║
 * ╚═══════════════════════════════╝
 *  [●]  Author Name   •  May 2025      ← author row
 *  ████████████████████████            ← H1 title (tall)
 *  ████████████████                    ← subtitle
 *  ─────────────────────────────────
 *  █████████████████████████████████   ← paragraph lines…
 *  ████████████████████████████████
 *  █████████████████████████
 *  …
 */
declare const ArticleSkeleton: React.MemoExoticComponent<({ animation, speed, baseColor, highlightColor, delay, showHero, paragraphLines, showAuthor, }: ArticleSkeletonProps) => import("react/jsx-runtime").JSX.Element>;
export default ArticleSkeleton;
export { ArticleSkeleton };
//# sourceMappingURL=ArticleSkeleton.d.ts.map