import React from 'react';
import type { SkeletonProps } from '../types';
export interface CardSkeletonProps extends Pick<SkeletonProps, 'animation' | 'speed' | 'baseColor' | 'highlightColor' | 'delay'> {
    /** Show the image/hero placeholder at the top. Defaults to true. */
    showImage?: boolean;
    /** Number of text lines below the image. Defaults to 3. */
    lines?: number;
}
/**
 * Pre-built card skeleton layout:
 *
 * ┌─────────────────────────┐
 * │   [image placeholder]   │
 * │  ████████████           │  ← title
 * │  ████████████████████   │  ← subtitle
 * │  ████████               │  ← tag/badge
 * └─────────────────────────┘
 */
declare const CardSkeleton: React.MemoExoticComponent<({ animation, speed, baseColor, highlightColor, delay, showImage, lines, }: CardSkeletonProps) => import("react/jsx-runtime").JSX.Element>;
export default CardSkeleton;
export { CardSkeleton };
//# sourceMappingURL=CardSkeleton.d.ts.map