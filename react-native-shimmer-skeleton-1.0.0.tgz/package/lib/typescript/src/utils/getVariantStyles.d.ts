import type { ViewStyle } from 'react-native';
import type { SkeletonVariant } from '../types';
/**
 * Returns baseline ViewStyle for a given skeleton variant.
 * These are defaults and can be overridden via explicit props.
 */
export declare function getVariantStyles(variant?: SkeletonVariant): ViewStyle;
//# sourceMappingURL=getVariantStyles.d.ts.map